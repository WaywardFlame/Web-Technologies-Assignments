<?php
session_start();

$servername = "localhost";
$username = "hw11";
$password = "thedrzpassword";
$dbname = "hw11";

// Create a connection
try {
    $conn = new mysqli($servername, $username, $password, $dbname);
} catch (Exception $e) {
    die("Connection failed: " . $e);
}

// set variables
$numSet = 0;

if(isset($_GET["firstName"])){
  $_SESSION["firstName"] = $_GET["firstName"];
  $numSet += 1;
} else {
  $_SESSION["firstName"] = "";
}

if(isset($_GET["lastName"])){
  $_SESSION["lastName"] = $_GET["lastName"];
  $numSet += 1;
} else {
  $_SESSION["lastName"] = "";
}

if(isset($_GET["jobTitle"])){
  $_SESSION["jobTitle"] = $_GET["jobTitle"];
  $numSet += 1;
} else {
  $_SESSION["jobTitle"] = "";
}

if(isset($_GET["EmailBox"])){
  $_SESSION["EmailBox"] = $_GET["EmailBox"];
  $numSet += 1;
} else {
  $_SESSION["EmailBox"] = "";
}

if(isset($_GET["Office"])){
  $_SESSION["office"] = $_GET["Office"];
  $numSet += 1;
} else {
  $_SESSION["office"] = "";
}

// validation of variables
if($numSet == 5){
  $error = "";
  $validEmail = true;
  $validTitle = true;

  if(!str_ends_with($_SESSION["EmailBox"], ".com")){
    $error = $error . "email not in valid format: must end with .com<br/>";
    $validEmail = false;
  }
  
  if(strlen($_SESSION["jobTitle"]) < 6){
    $error = $error . "job title not in valid format: must be at least six characters<br/>";
    $validTitle = false;
  }

  if(!$validEmail || !$validTitle){
    $_SESSION["error"] = $error;

    if(!$validEmail){
      $_SESSION["validEmail"] = "invalid email";
    } else {
      $_SESSION["validEmail"] = "";
    }
    
    if(!$validTitle){
      $_SESSION["validTitle"] = "invalid title";
    } else {
      $_SESSION["validTitle"] = "";
    }

    header("Location: ./EmployeeForm.php");
    $conn->close();
    exit();
  }

  $officeCode = 0;
  if(strcmp($_SESSION["office"], "San Francisco") === 0){
    $officeCode = 1;
  } else if(strcmp($_SESSION["office"], "Boston") === 0){
    $officeCode = 2;
  } else if(strcmp($_SESSION["office"], "NYC") === 0){
    $officeCode = 3;
  } else if(strcmp($_SESSION["office"], "Paris") === 0){
    $officeCode = 4;
  } else if(strcmp($_SESSION["office"], "Tokyo") === 0){
    $officeCode = 5;
  } else if(strcmp($_SESSION["office"], "Sydney") === 0){
    $officeCode = 6;
  } else if(strcmp($_SESSION["office"], "London") === 0){
    $officeCode = 7;
  }

  $sql = "INSERT INTO employees VALUES ('" . rand(2000, 12000) . "', '" . $_SESSION["lastName"] . "', '" . $_SESSION["firstName"] . "', 'x" . rand(0, 9999) . "', '" . $_SESSION["EmailBox"] . "', '" . $officeCode . "', '" . rand(1000, 2000) . "', '" . $_SESSION["jobTitle"] . "')";
  $conn->query($sql);
}

// Execute the query
$sql = "SELECT E.firstName, E.lastName, O.city, O.state, O.country FROM employees as E, offices as O where E.officeCode = O.officeCode";
$result = $conn->query($sql);

// go over the results
if ($result->num_rows > 0) {
  echo "<table><tr><th></th><th>Last</th><th>First</th><th>City</th><th>State</th><th>Country</th></tr>" ;
  $k=0;
  while($row = $result->fetch_assoc()) {
    echo '<tr>' ; 
    echo '<td>' . ++$k . ')</td>' ; 
    foreach(['lastName','firstName','city','state','country'] as $key) {
        echo '<td>' . $row[$key] . '</td>' ; 
    }
    echo '</tr>' ; 
  }
  echo '</table>' ;
} else {
  echo "0 results";
}

$conn->close();    

unset($_SESSION["validEmail"]);
unset($_SESSION["validTitle"]);
unset($_SESSION["EmailBox"]);
unset($_SESSION["jobTitle"]);
unset($_SESSION["firstName"]);
unset($_SESSION["lastName"]);
unset($_SESSION["office"]);
unset($_SESSION["error"]);
?>

<form id="AddEmployeeForm" action="EmployeeForm.php">
    <input type="submit" id="AddEmployee" name="AddEmployee" value="Add New Employee"/>
</form>