<?php 
session_start();

$servername = "localhost";
$username = "hw11";
$password = "thedrzpassword";
$dbname = "hw11";

try {
    $conn = new mysqli($servername, $username, $password, $dbname);
} catch (Exception $e) {
    die("Connection failed: " . $e);
}

if(isset($_SESSION["validEmail"]) && $_SESSION["validEmail"] != ""){
    $email = "";
} else if(isset($_SESSION["EmailBox"])){
    $email = $_SESSION["EmailBox"];
} else {
    $email = "";
}

if(isset($_SESSION["validTitle"]) && $_SESSION["validTitle"] != ""){
    $title = "";
} else if(isset($_SESSION["jobTitle"])){
    $title = $_SESSION["jobTitle"];
} else {
    $title = "";
}

if(isset($_SESSION["office"])){
    $office = $_SESSION["office"];
} else {
    $office = "";
}

$sql = "SELECT city FROM offices";
$results = $conn->query($sql);
$officeLocations = $results->fetch_all();
?>

<!DOCTYPE html>
<html lang="eng-US">
    <head>
        <title>Assignment 12</title>
        <script>
            window.addEventListener("load", function() {
                document.getElementById("EmailBox").addEventListener("input", function(){
                    let formData = new FormData();
                    formData.append("email", document.getElementById("EmailBox").value);
                    fetch("https://ec2-3-17-181-72.us-east-2.compute.amazonaws.com/hw12/findEmail.php", {method: 'POST', body: formData}).then(function(response){
                        return response.text();
                    }).then(function(body){
                        let client = document.getElementById("Validation");
                        if(body === "true"){
                            client.innerHTML = "error: email already exists, resetting field";
                            document.getElementById("EmailBox").value = "";
                        } else {
                            client.innerHTML = "";
                        }
                    });
                });
                
	            const form = document.getElementById("addingEmployee");
	            let formData = null;

	            function isValid_firstname(){
        	        const firstName = formData.get('firstName');
        	        console.log("checking first name:", firstName);
        	        let isAcceptable = /^[A-Za-z\-\']+$/.test(firstName) && (firstName.length >= 2);
        	        if(!isAcceptable){
            		    console.log("first name not acceptable");
            		    return false;
        	        }
        	        return true;
    	        }

	            function isValid_lastname(){
		            const lastName = formData.get('lastName');
		            console.log("checking last name:", lastName);
		            let isAcceptable = /^[A-Za-z\-\']+$/.test(lastName) && (lastName.length >= 2);
		            if(!isAcceptable){
			            console.log("last name not acceptable");
			            return false;
		            }
		            return true;
	            }

	            function isValid_jobtitle() {
		            const jobTitle = formData.get('jobTitle');
		            console.log("checking job title:", jobTitle);
		            let isAcceptable = /^[A-Za-z0-9\-]+$/.test(jobTitle) && (jobTitle.length >= 4);
		            if(!isAcceptable){
			            console.log("job title not acceptable");
			            return false;
		            }
		            return true;
	            }

	            function isFormValid() {
		            formData = new FormData(form);
		            return isValid_firstname() && isValid_lastname() && isValid_jobtitle();
	            }

	            form.addEventListener("submit", function(event) {
		            console.log("user is trying to submit");
		            if(!isFormValid()){
			            event.preventDefault();
                        let client = document.getElementById("Validation");
                        client.innerHTML = "";
			            if(!isValid_firstname()){
                            client.innerHTML += "first name not in valid format: must be 2 chars long min, alphabet chars, hyphens and apostrophes only<br/>";
                        }
                        if(!isValid_lastname()){
                            client.innerHTML += "last name not in valid format: must be 2 chars long min, alphabet chars, hyphens and apostrophes only<br/>";
                        }
                        if(!isValid_jobtitle()){
                            client.innerHTML += "job title not in valid format: must be 4 chars long min, alphabet chars, and hyphens only<br/>";
                        }
		            }
	            });
            });
        </script>
    </head>
    <body>
        <p id="Validation">
            <?php 
            if(isset($_SESSION["error"])){
                echo $_SESSION["error"];
            }
            ?>
        </p>
        <form id="addingEmployee" action="index.php" method="get">
            <label for="firstName">First Name:</label><br/>
            <input type="text" id="firstName" name="firstName" value=<?php echo '"'.$_SESSION["firstName"].'"'; ?> required><br/>

            <label for="lastName">Last Name:</label><br/>
            <input type="text" id="lastName" name="lastName" value=<?php echo '"'.$_SESSION["lastName"].'"'; ?> required><br/>

            <label for="jobTitle">Job Title:</label><br/>
            <input type="text" id="jobTitle" name="jobTitle" value=<?php echo '"'.$title.'"'; ?> required><br/>

            <label for="EmailBox">Email:</label><br/>
            <input type="email" id="EmailBox" name="EmailBox" value=<?php echo '"'.$email.'"'; ?> required><br/>

            <label for="Office">Office:</label><br/>
            <select name="Office">
                <option value="">--Select an Office--</option>
                <?php 
                for($i = 0; $i < sizeof($officeLocations); $i++){
                    if($officeLocations[$i][0] === $office){
                        echo "<option value=\"{$officeLocations[$i][0]}\" selected=\"selected\">{$officeLocations[$i][0]}</option>"; 
                    } else {
                        echo "<option value=\"{$officeLocations[$i][0]}\">{$officeLocations[$i][0]}</option>"; 
                    }
                }
                ?>
            </select><br/><br/>

            <input type="reset" id="resetButton" name="resetButton" value="Reset">
            <input type="submit" id="submitButton" name="submitButton" value="Submit">
        </form>
    </body>
</html>