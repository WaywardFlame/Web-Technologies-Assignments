<?php 
$servername = "localhost";
$username = "hw11";
$password = "thedrzpassword";
$dbname = "hw11";

try {
    $conn = new mysqli($servername, $username, $password, $dbname);
} catch (Exception $e) {
    die("Connection failed: " . $e);
}

$sql = "SELECT email FROM employees";
$results = $conn->query($sql);
$emails = $results->fetch_all();

if(isset($_POST["email"])){
    $toCompare = $_POST["email"];
} else {
    $toCompare = "";
}

$num = 0;
for($i = 0; $i < sizeof($emails); $i++){
    if(strcmp($toCompare, $emails[$i][0]) === 0){
        $num = $i;
        break;
    }
}

if($num === 0){
    echo "false";
} else {
    echo "true";
}
?>