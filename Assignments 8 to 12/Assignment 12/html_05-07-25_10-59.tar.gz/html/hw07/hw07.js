"use strict";
let boxURL = "";
let tiles = [];

function DivideImage() {
    let imageToDivide = document.getElementById('primaryImage');
    let imagePieces = [ [], [], [], [] ];
    let pieceWidth = Math.floor(imageToDivide.width / 4);
    let pieceHeight = Math.floor(imageToDivide.height / 4);
    for(let i = 0; i < 4; i++){
        for(let k = 0; k < 4; k++){
            let canvas = document.createElement('canvas');
            canvas.width = pieceWidth;
            canvas.height = pieceHeight;
            let context = canvas.getContext('2d');
            context.drawImage(imageToDivide, i * pieceWidth, k * pieceHeight, pieceWidth, pieceHeight, 0, 0, canvas.width, canvas.height);
            imagePieces[i].push(canvas.toDataURL());
            if(i === 3 && k === 3){
                boxURL = canvas.toDataURL();
            }
        }
    }
    return imagePieces;
}

function RandomizeImages(tilesToRandomize){
    for(let i = 0; i < 4; i++){
        for(let k = 0; k < 4; k++){
            let temp = tilesToRandomize[i][k];
            let rn = k;
            while(rn === k){
                rn = Math.floor(Math.random() * 4);
            }
            tilesToRandomize[i][k] = tilesToRandomize[i][rn];
            tilesToRandomize[i][rn] = temp; 
        }
    }
    for(let i = 0; i < 4; i++){
        for(let k = 0; k < 4; k++){
            let temp = tilesToRandomize[k][i];
            let rn = k;
            while(rn === k){
                rn = Math.floor(Math.random() * 4);
            }
            tilesToRandomize[k][i] = tilesToRandomize[rn][i];
            tilesToRandomize[rn][i] = temp;
        }
    }
    return tilesToRandomize;
}

function CreatePuzzleTable(puzzleTiles){
    let table = document.createElement('table');
    for(let i = 0; i < 4; i++){
        let tr = document.createElement('tr');
        for(let k = 0; k < 4; k++){
            let td = document.createElement('td');
            let image = new Image();
            image.src = puzzleTiles[i][k];
            if(image.src === boxURL){
                image.hidden = true;
            }
            image.addEventListener('click', function(){
                FindAndSwapTile(image);
            });
            td.appendChild(image);
            tr.appendChild(td);
        }
        table.appendChild(tr);
    }
    return table;
}

function FindAndSwapTile(image){
    if(image.src === boxURL){
        return;
    }

    let x = 0;
    let y = 0;
    for(let i = 0; i < 4; i++){
        for(let k = 0; k < 4; k++){
            if(image.src === tiles[i][k]){
                x = i;
                y = k;
                break;
            }
        }
    }

    let images = document.getElementById('puzzleTable').getElementsByTagName('img');
    let x1 = x - 1;
    let x2 = x + 1;
    let y1 = y - 1;
    let y2 = y + 1;
    // check above tile
    if(x1 >= 0){
        if(tiles[x1][y] === boxURL){
            for(let i = 0; i < images.length; i++){
                if(images[i].src === tiles[x1][y]){
                    images[i].src = image.src;
                    images[i].hidden = false;
                    image.hidden = true;
                }
            }
            tiles[x1][y] = image.src;
            image.src = boxURL;
            tiles[x][y] = boxURL;
            return;
        }
    }
    // check below tile
    if(x2 <= 3){
        if(tiles[x2][y] === boxURL){
            for(let i = 0; i < images.length; i++){
                if(images[i].src === tiles[x2][y]){
                    images[i].src = image.src;
                    images[i].hidden = false;
                    image.hidden = true;
                }
            }
            tiles[x2][y] = image.src;
            image.src = boxURL;
            tiles[x][y] = boxURL;
            return;
        }
    }
    // check left tile
    if(y1 >= 0){
        if(tiles[x][y1] === boxURL){
            for(let i = 0; i < images.length; i++){
                if(images[i].src === tiles[x][y1]){
                    images[i].src = image.src;
                    images[i].hidden = false;
                    image.hidden = true;
                }
            }
            tiles[x][y1] = image.src;
            image.src = boxURL;
            tiles[x][y] = boxURL;
            return;
        }
    }
    // check right tile
    if(y2 <= 3){
        if(tiles[x][y2] === boxURL){
            for(let i = 0; i < images.length; i++){
                if(images[i].src === tiles[x][y2]){
                    images[i].src = image.src;
                    images[i].hidden = false;
                    image.hidden = true;
                }
            }
            tiles[x][y2] = image.src;
            image.src = boxURL;
            tiles[x][y] = boxURL;
            return;
        }
    }
}

window.addEventListener('load', function(){
    tiles = DivideImage();
    tiles = RandomizeImages(tiles);
    let puzzleTable = CreatePuzzleTable(tiles);
    puzzleTable.id = "puzzleTable";
    this.document.getElementById('puzzle').appendChild(puzzleTable);
});